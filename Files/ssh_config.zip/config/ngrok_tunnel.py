#!/usr/bin/python3
import os
try:
    from pyngrok import ngrok, conf
except:
    os.system('pip3 install pyngrok')
    from pyngrok import ngrok, conf

NGROK_AUTH_TOKEN="1wGhC9pHNJOjr510L7Yjxhg8dXl_4UHWhR571cjdCewzaNN4u"
ngrok.set_auth_token(NGROK_AUTH_TOKEN)
conf.get_default().region = "in"
ssh_tunnel = ngrok.connect(9870, "tcp")
tcp_url=ssh_tunnel.public_url
url=tcp_url[6:].split(':')
print(f'[>SSH]: ssh root@{url[0]} -p{url[1]}')
input()
